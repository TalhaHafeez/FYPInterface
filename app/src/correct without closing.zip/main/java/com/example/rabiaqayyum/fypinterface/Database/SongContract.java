package com.example.rabiaqayyum.fypinterface.Database;

import android.net.Uri;
import android.provider.BaseColumns;

public class SongContract
{
    private SongContract()
    {

    }
    public static final String CONTENT_AUTHORITY = "com.example.rabiaqayyum.fypinterface";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_Songs = "Songs";

    public static final String PATH_Playlists = "Playlists";

    //public static final String PATH_Favourites = "Favourites";

    public static final String PATH_Playlists_Songs = "PlaylistsSongs_Assoc";

    public static final class SongsTable implements BaseColumns {


        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_Songs);


        /** Name of database table for devices */

        public final static String TABLE_NAME = "Songs";

        public final static String COLUMN_Song_ID = "song_id";

        public final static String COLUMN_Song_Path = "song_path";

        public final static String COLUMN_Song_duration="song_duration";


        public final static String COLUMN_Song_Name ="song_name";


        public final static String COLUMN_Favourite_id = "favourite_id";

        public final static int nFavourite_id=0;
        public final static int yFavourite_id=1;

    }


    public static final class PlaylistsTable implements BaseColumns {


        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_Playlists);


        /** Name of database table for devices */

        public final static String TABLE_NAME = "Playlists";

        public final static String COLUMN_Playlist_ID = "playlist_id";

        public final static String COLUMN_Playlist_Name = "playlist_name";

        public static final String playlist_happy="Happy";
        public static final String playlist_sad="Sad";
        public static final String playlist_neutral="Neutral";
        public static final String playlist_angry="Angry";
        public static final String playlist_surprise="Surprise";
        public static final String playlist_fear="Fear";


    }

  /*  public static final class FavouritesTable implements BaseColumns {


        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_Favourites);


        /** Name of database table for devices */

  /*      public final static String TABLE_NAME = "Favourites";

        public final static String COLUMN_Favourite_ID = BaseColumns._ID;

        public final static String COLUMN_Rank = "rank";


        public static final int rank1=1;
        public static final int rank2=2;
        public static final int rank3=3;
        public static final int rank4=4;
        public static final int rank5=5;
    }*/

    public static final class PlaylistsSongs_AssocTable implements BaseColumns {


        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_Playlists_Songs);


        /** Name of database table for devices */

        public final static String TABLE_NAME = "PlaylistsSongs_Assoc";

        public final static String COLUMN_Song_ID = "song_id";

        public final static String COLUMN_Playlist_ID = "playlist_id";

    }


}

