package com.example.rabiaqayyum.fypinterface;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.media.session.MediaControllerCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by RABIA QAYYUM on 4/10/2018.
 */

public class songPlayer extends Activity implements  MediaPlayer.OnCompletionListener, View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    public static final String ACTION_PLAY = "com.example.rabiaqayyum.fypinterface.ACTION_PLAY";
    public static final String ACTION_PAUSE = "com.example.rabiaqayyum.fypinterface.ACTION_PAUSE";
    public static final String ACTION_PREVIOUS = "com.example.rabiaqayyum.fypinterface.ACTION_PREVIOUS";
    public static final String ACTION_NEXT = "com.example.rabiaqayyum.fypinterface.ACTION_NEXT";
    public static final String ACTION_STOP = "com.example.rabiaqayyum.fypinterface.ACTION_STOP";
    public static final String ACTION_FORWARD="com.example.rabiaqayym.fypinterface.ACTION_FORWARD";
    public static final String ACTION_REVERSE="com.example.rabiaqayym.fypinterface.ACTION_REVERSE";

    Intent serviceIntent;

    // --Seekbar variables --
   // private SeekBar seekBar;
    SeekBar songProgressBar;
    private int seekMax;
    private static int songEnded = 0;
    boolean mBroadcastIsRegistered;

    public static final String BROADCAST_SEEKBAR = "com.example.rabiaqayym.fypinterface.sendseekbar";
    Intent intent;



    Boolean mBound;
    ArrayList<Song> songList;
    int activeSongIndex;
    Button previous,reverse,play,forward,next;
    ImageView playing,icon;
    TextView itemname;
    TextView artistname;

   // private  MediaPlayer mp;
    // Handler to update UI timer, progress bar etc,.
    private Handler mHandler = new Handler();;
  //  private SongsManager songManager;
    private Utilities utils;
    private StorageUtility storage;
    private int seekForwardTime = 5000; // 5000 milliseconds
    private int seekBackwardTime = 5000; // 5000 milliseconds
    private int currentSongIndex = 0;
    private boolean isShuffle = false;
    private boolean isRepeat = false;

    private boolean isBound=false;
    private MediaPlayerService mps;

    private long currentPosition;
    private long totalDuration;
    private static int state=1;//0  pause    1 playing

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        songList=new ArrayList<>();
        mps=new MediaPlayerService();
        setContentView(R.layout.songplayer);
        previous=(Button) findViewById(R.id.previous);
        reverse=(Button) findViewById(R.id.reverse);
        play=(Button)findViewById(R.id.play);
        forward=(Button)findViewById(R.id.forward);
        next=(Button)findViewById(R.id.next);


        itemname=(TextView)findViewById(R.id.Itemname);
        artistname=(TextView)findViewById(R.id.artistName);

        icon=(ImageView) findViewById(R.id.icon);
        playing=(ImageView) findViewById(R.id.playing);

        songProgressBar=(SeekBar) findViewById(R.id.seekbar);

        serviceIntent = new Intent(this, MediaPlayerService.class);

        // --- set up seekbar intent for broadcasting new position to service ---
        intent = new Intent(BROADCAST_SEEKBAR);




       // mp=new MediaPlayer();
        utils=new Utilities();
        storage=new StorageUtility(this);
        songList=storage.loadAudio();
        activeSongIndex=storage.loadAudioIndex();

        songProgressBar.setOnSeekBarChangeListener(this);

        registerReceiver(broadcastReceiver, new IntentFilter(
                MediaPlayerService.BROADCAST_ACTION));
        ;
        mBroadcastIsRegistered = true;
       // updateProgressBar();

       // songProgressBar.setOnSeekBarChangeListener(this);

      //  mp.setOnCompletionListener(this);

        itemname.setText(songList.get(activeSongIndex).getTitle());
        artistname.setText(songList.get(activeSongIndex).getTitle());

        play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));
        previous.setOnClickListener(this);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(songPlayer.this,MediaPlayerService.class);
                intent.setAction(ACTION_NEXT);
                startService(intent);
                int songCheck=activeSongIndex+1;
                if(songCheck<songList.size()) {
                    itemname.setText(songList.get(++activeSongIndex).getTitle());
                }
                else
                {
                    activeSongIndex=0;
                    itemname.setText(songList.get(activeSongIndex).getTitle());
                }
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(state==1)
                {
                    //Bitmap image=
                   // play.setBackgroundDrawable(R.drawable.pause);
                    play.setBackgroundDrawable(getResources().getDrawable(R.drawable.play));

                    state=0;
                    Intent intent=new Intent(songPlayer.this,MediaPlayerService.class);
                    intent.setAction(ACTION_PAUSE);
                    startService(intent);

                }
                else
                {
                    play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));

                    state=1;
                    Intent intent=new Intent(songPlayer.this,MediaPlayerService.class);
                    intent.setAction(ACTION_PLAY);
                    startService(intent);

                    registerReceiver(broadcastReceiver, new IntentFilter(
                            MediaPlayerService.BROADCAST_ACTION));
                    ;
                    mBroadcastIsRegistered = true;
                  //  Intent
                }
            }
        });
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(songPlayer.this,MediaPlayerService.class);
                intent.setAction(ACTION_FORWARD);
                startService(intent);
                play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));
            }
        });

        reverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(songPlayer.this,MediaPlayerService.class);
                intent.setAction(ACTION_REVERSE);
                startService(intent);
                play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));
            }
        });

       // Intent receive=getIntent();

     //   Bundle args=receive.getBundleExtra("bundle");

     //   ArrayList<Song> songList=args.getSerializable("songarraylist");

    }
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent serviceIntent) {
            updateUI(serviceIntent);
        }
    };

    private void updateUI(Intent serviceIntent) {
        String counter = serviceIntent.getStringExtra("counter");
        String mediamax = serviceIntent.getStringExtra("mediamax");
        String strSongEnded = serviceIntent.getStringExtra("song_ended");
        int seekProgress = Integer.parseInt(counter);
        seekMax = Integer.parseInt(mediamax);
        songEnded = Integer.parseInt(strSongEnded);
        songProgressBar.setMax(seekMax);
        songProgressBar.setProgress(seekProgress);
        if (songEnded == 1) {
            play.setBackgroundResource(R.drawable.play);
        }
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {


    }
    /*

    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MediaPlayerService.LocalBinder binder = (MediaPlayerService.LocalBinder) service;
            mps = binder.getService();
            mBound = true;

        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };*/





    ///previous button
    @Override
    public void onClick(View view) {
        /*MediaControllerCompat.TransportControls controls = MediaControllerCompat.getMediaController(songPlayer.this).getTransportControls();
        controls.skipToNext();*/
       Intent intent=new Intent(this,MediaPlayerService.class);
       intent.setAction(ACTION_PREVIOUS);
       startService(intent);
       int songCheck=activeSongIndex-1;
       if(songCheck>=0)
       {
           itemname.setText(songList.get(--activeSongIndex).getTitle());
       }
       else
       {
           activeSongIndex=songList.size()-1;
           itemname.setText(songList.get(activeSongIndex).getTitle());
       }

    }



   /*  BroadcastReceiver br=new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle parameters=getIntent().getExtras();
        //  currentPosition=parameters.getLongExtra("currentPosition");
        if(getIntent().getAction()=="seekbar") {
            currentPosition = parameters.getLong("currentPosition");
            totalDuration = parameters.getLong("duration");
            // songProgressBar.setMax((int)totalDuration);
            //songProgressBar.setProgress((int)currentPosition);
            Log.e("duration", totalDuration + "");
            Log.e("position", currentPosition + "");
        }

        songProgressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
};
*/

    @Override
    protected void onResume() {
        super.onResume();
        //registerReceiver(br,new IntentFilter("Broadcast"));
        registerReceiver(broadcastReceiver, new IntentFilter(
                MediaPlayerService.BROADCAST_ACTION));
        mBroadcastIsRegistered=true;

    }

    @Override
    protected void onPause() {
        super.onPause();
       // unregisterReceiver(br);
        unregisterReceiver(broadcastReceiver);
        mBroadcastIsRegistered=false;
    }

    @Override
    public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
        if (fromUser) {
            int seekPos = sb.getProgress();
            intent.putExtra("seekpos", seekPos);
            sendBroadcast(intent);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
