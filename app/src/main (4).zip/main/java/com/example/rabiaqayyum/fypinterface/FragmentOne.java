package com.example.rabiaqayyum.fypinterface;

import android.app.Activity;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.File;

import static android.app.Activity.RESULT_OK;


public class FragmentOne extends Fragment implements View.OnClickListener {

    String Path;
    String fileName;


    Button play;
    Button b2,b3,b4,b5,b6,b7;
    Camera mCamera;
    boolean mPreviewRunning = false;
    AddingRemovingSongs ars;

    final int request_code=100;
    Bundle instance;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    /*protected void playClick(View view)
    {

    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fragment_one, container, false);
        ars=new AddingRemovingSongs(this);
        play=(Button)view.findViewById(R.id.play);




        b2=(Button) view.findViewById(R.id.button2);
        b3=(Button) view.findViewById(R.id.button3);
        b4=(Button) view.findViewById(R.id.button4);
        b5=(Button) view.findViewById(R.id.button5);
        b6=(Button) view.findViewById(R.id.button6);
        b7=(Button) view.findViewById(R.id.button7);


        //*************************************ON CLICK LISTENERS******************************************
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b2.getText().toString());
                startActivity(myIntent);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b3.getText().toString());
                startActivity(myIntent);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b4.getText().toString());
                startActivity(myIntent);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b5.getText().toString());
                startActivity(myIntent);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b6.getText().toString());
                startActivity(myIntent);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), songsList.class);
                myIntent.putExtra("playlistName",b7.getText().toString());
                startActivity(myIntent);
            }
        });

        //***********************************ON LONG CLICK LISTENERS************************************
        b2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b2, Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {

                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b2.getText().toString());
                                                                     ars.addSongs(b2.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        b3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b3,Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {
                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b3.getText().toString());
                                                                     ars.addSongs(b3.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        b4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b4,Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {
                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b4.getText().toString());
                                                                     ars.addSongs(b4.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        b5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b5,Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {
                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b5.getText().toString());
                                                                     ars.addSongs(b5.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        b6.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b6,Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {
                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b6.getText().toString());
                                                                     ars.addSongs(b6.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        b7.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final PopupMenu popupMenu = new PopupMenu(getContext(), b7,Gravity.CENTER);
                popupMenu.getMenuInflater().inflate(R.menu.playlistbuttonpopup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                                         @Override
                                                         public boolean onMenuItemClick(MenuItem item) {
                                                             switch (item.getItemId())
                                                             {
                                                                 case R.id.addSongs:
                                                                     Log.e("b2",b7.getText().toString());
                                                                     ars.addSongs(b7.getText().toString());
                                                                     return true;
                                                                 case R.id.removeSongs:
                                                                     ars.removeSongs();
                                                                     return true;
                                                                 case R.id.viewPlaylist:
                                                                     return true;
                                                                 default:
                                                                     return false;
                                                             }
                                                         }
                                                     }
                );
                popupMenu.show();
                return true;
            }


        });

        //*********************************************************************************************
        play.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        /*if(v.getId()==play.getId())
        {
            cameraClass cc=new cameraClass(v);
        }*/

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        /*fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);*/
        startActivityForResult(intent,request_code);




    }

    private String[] getRealPathFromURI(Context context, Uri contentUri) {
       // String[] projection = { MediaStore.Audio.Media.DATA };
        String[] song=new String[4];
        CursorLoader loader = new CursorLoader(context, contentUri, null, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int path_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
        int name_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
        int duration_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
        int artist_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
        cursor.moveToFirst();
        //do {
            String songPath=cursor.getString(path_index);
            String songName=cursor.getString(name_index);
            String songDuration=cursor.getString(duration_index);
            String songArtist=cursor.getString(artist_index);

            song[0]=songPath;
            song[1]=songName;
            song[2]=songDuration;
            song[3]=songArtist;
       // }while (cursor.moveToNext());
        return song;

    }
    @Override
     public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100&&resultCode==RESULT_OK)
        {
            Intent myIntent = new Intent(getActivity(), songsList.class);
            startActivity(myIntent);
        }
        if(requestCode==7 && resultCode==RESULT_OK)
        {
            String song[];
            Uri uri=data.getData();

            //if(uri.getScheme().equals("content"))
          //  {
               // Log.e("content","the path has content");
            //}
            if(uri!=null)
            {
                song=getRealPathFromURI(getContext(),uri);
                for(int i=0;i<song.length;i++) {
                    Log.e("path", song[i]);
                }
            }
            else
            {
                song=null;
            }



            ars.addToDatabaseAndListView(song[1],song[0],Float.parseFloat(song[2]));



/*
            Log.e("uri",uri.toString());
            String temp=data.getData().getPath();
            if(temp.contains(":")) {
                Log.i("info", "path " + temp + "index " + temp.indexOf(":") + " " + temp.substring(temp.indexOf(":") + 1));
                Path = Environment.getExternalStorageDirectory().toString() + "/" + temp.substring(temp.indexOf(":") + 1);
            }else{
                Path = temp;
            }
            try {
                File file = new File(Path);
                // Toast.makeText(this, "File Selected", Toast.LENGTH_LONG).show();
                Log.i("info", " File " + file);
                if (file != null) {
                    Log.i("info", "file Path :" + Path + " absolutepath " + file.getAbsolutePath() + " " + file.getCanonicalPath());
                    fileName = file.getName();
                    //filename.setText(fileName);
                    //fileId=uri.
                    Log.i("info", "file Name :" + fileName);
                    //  int file_size = Integer.parseInt(String.valueOf(file.length()/1024));
                    // fileType = getExt(Path);
                    //type.setText(fileType);
                    // Log.i("info", "file type :" + getExt(Path));

                    float s = file.length() / 1024;
                    float fsize = s / 1024;

                    Log.i("info", "file Size :" + s + " " + file.exists() + " " + file);
                    //  size.setText(""+fsize);*/

                 /*  ars.addToDatabaseAndListView(fileName,Path,fsize);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
*/

        }
    }
}
