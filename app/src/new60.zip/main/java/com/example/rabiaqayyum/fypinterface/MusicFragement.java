package com.example.rabiaqayyum.fypinterface;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class MusicFragement extends Fragment {

    TextView activeSongName;
    Button playPause;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.player_below, container, false);
        activeSongName=(TextView)view.findViewById(R.id.textView);
        playPause=(Button)view.findViewById(R.id.play);

        return view;

    }
}
