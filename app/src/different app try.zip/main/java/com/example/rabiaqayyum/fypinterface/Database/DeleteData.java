package com.example.rabiaqayyum.fypinterface.Database;

import android.content.ContentUris;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import java.util.Objects;

public class DeleteData
{
    private Context newContext;
    public DeleteData()
    {

    }
    public DeleteData(Context context)
    {
        this.newContext=context;
    }
    public void delete(String tableName, long id)
    {
        if(Objects.equals(tableName,"Songs"))
        {
            Uri uri= ContentUris.withAppendedId(SongContract.SongsTable.CONTENT_URI,id);
            newContext.getContentResolver().delete(uri,null,null);
        }
    }
}
