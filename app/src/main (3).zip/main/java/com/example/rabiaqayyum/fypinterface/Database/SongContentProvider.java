package com.example.rabiaqayyum.fypinterface.Database;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

public class SongContentProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1) {
        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
/*
    public static final String LOG_TAG = SongContentProvider.class.getSimpleName();

    private static final int Songs=1;
    private static final int Playlists=2;
    private static final int Favourites=3;
    private static final int PlaylistsSongs_Assoc=4;

    private static final int Song_id=11;
    private static final int Playlist_id=12;
    private static final int Favourite_id=13;
    private static final int PlaylistsSongs_Assoc_id=14;

    private static final UriMatcher NewUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static
    {
        NewUriMatcher.addURI(SongContract.CONTENT_AUTHORITY, SongContract.PATH_Songs, Songs);
        NewUriMatcher.addURI(SongContract.CONTENT_AUTHORITY, SongContract.PATH_Playlists, Playlists);
       // NewUriMatcher.addURI(SongContract.CONTENT_AUTHORITY, SongContract.PATH_Favourites, Favourites);
        NewUriMatcher.addURI(SongContract.CONTENT_AUTHORITY, SongContract.PATH_Playlists_Songs, PlaylistsSongs_Assoc);
    }

    private  SongDatabaseHelper songDatabaseHelper;

    @Override
    public boolean onCreate() {
        songDatabaseHelper=new SongDatabaseHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1)
    {
        SQLiteDatabase database = songDatabaseHelper.getReadableDatabase();
        SQLiteQueryBuilder newQueryBuilder = new SQLiteQueryBuilder();
        Cursor cursor;


        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {

        final int match = NewUriMatcher.match(uri);
        switch (match)
        {
            case Songs:
                return insertSong(uri,contentValues);
            case Playlists:
                return insertPlaylist(uri,contentValues);
            case PlaylistsSongs_Assoc:
                return insertPlaylistsSongs_Assoc(uri, contentValues);
            default:
                throw new IllegalArgumentException("Insertion is not supported for " + uri);

        }
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Get writeable database
        SQLiteDatabase database = songDatabaseHelper.getWritableDatabase();

        // Track the number of rows that were deleted
        int rowsDeleted;

        final int match = NewUriMatcher.match(uri);
        switch (match) {
            case Songs:
                // Delete all rows that match the selection and selection args
                rowsDeleted = database.delete(SongContract.SongsTable.TABLE_NAME, selection, selectionArgs);
                break;

            case Song_id:
                // Delete a single row given by the ID in the URI
                selection = SongContract.SongsTable._ID + "=?";
                selectionArgs = new String[] { String.valueOf(ContentUris.parseId(uri)) };
                rowsDeleted = database.delete(SongContract.SongsTable.TABLE_NAME, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Deletion is not supported for " + uri);
        }

        // If 1 or more rows were deleted, then notify all listeners that the data at the
        // given URI has changed
        if (rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }

        // Return the number of rows deleted
        return rowsDeleted;
    }

    private Uri insertSong(Uri uri, ContentValues values) {

        SQLiteDatabase database = songDatabaseHelper.getWritableDatabase();

        long id = database.insert(SongContract.SongsTable.TABLE_NAME, null, values);
        if (id == -1) {
            Log.e(LOG_TAG, "Failed to insert row for " + uri);

            return null;
        }

        // Notify all listeners that the data has changed for the pet content URI
        getContext().getContentResolver().notifyChange(uri, null);

        // Once we know the ID of the new row in the table,
        // return the new URI with the ID appended to the end of it
        return ContentUris.withAppendedId(uri, id);
    }

    private Uri insertPlaylist(Uri uri, ContentValues values) {

        SQLiteDatabase database = songDatabaseHelper.getWritableDatabase();

        long id = database.insert(SongContract.PlaylistsTable.TABLE_NAME, null, values);
        if (id == -1) {
            Log.e(LOG_TAG, "Failed to insert row for " + uri);

            return null;
        }

        // Notify all listeners that the data has changed for the pet content URI
        getContext().getContentResolver().notifyChange(uri, null);

        // Once we know the ID of the new row in the table,
        // return the new URI with the ID appended to the end of it
        return ContentUris.withAppendedId(uri, id);
    }
    private Uri insertPlaylistsSongs_Assoc(Uri uri, ContentValues values) {

        SQLiteDatabase database = songDatabaseHelper.getWritableDatabase();

        long id = database.insert(SongContract.PlaylistsSongs_AssocTable.TABLE_NAME, null, values);
        if (id == -1) {
            Log.e(LOG_TAG, "Failed to insert row for " + uri);

            return null;
        }

        // Notify all listeners that the data has changed for the pet content URI
        getContext().getContentResolver().notifyChange(uri, null);

        // Once we know the ID of the new row in the table,
        // return the new URI with the ID appended to the end of it
        return ContentUris.withAppendedId(uri, id);
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }*/
}
