package com.example.rabiaqayyum.fypinterface.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
public class AddDataInDatabase
{
   /* private Context newContext;
    public SongDatabaseHelper songDatabaseHelper;
    private final String query_song_id="SELECT _ID FROM Songs WHERE song_name=?";
    private final String query_playlist_id="SELECT _ FROM Playlists WHERE song_name=?";
    private final String query_favourite_id="SELECT favourite_id FROM Songs WHERE song_name=?";

    public AddDataInDatabase()
    {

    }
    public void Songs(String song_name,String song_path,String song_unique_id,int favourite_id)
    {
        ContentValues values = new ContentValues();
        values.put(SongContract.SongsTable.COLUMN_Song_Name,song_name);
        values.put(SongContract.SongsTable.COLUMN_Song_Path,song_path);
        values.put(SongContract.SongsTable.COLUMN_Song_unique_id,song_unique_id);
        values.put(SongContract.SongsTable.COLUMN_Favourite_id,favourite_id);

        Uri newUri1 = newContext.getContentResolver().insert(SongContract.SongsTable.CONTENT_URI, values);
    }

    public void Playlists()
    {
        ContentValues values=new ContentValues();
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_happy);
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_angry);
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_sad);
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_fear);
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_neutral);
        values.put(SongContract.PlaylistsTable.COLUMN_Playlist_Name,SongContract.PlaylistsTable.playlist_surprise);

        Uri newUri1 = newContext.getContentResolver().insert(SongContract.PlaylistsTable.CONTENT_URI, values);
    }
    public void playlistsSongs_Assoc(String song_name,String playlist_name)
    {
        SQLiteDatabase db = songDatabaseHelper.getReadableDatabase();

        Cursor getSongId=db.rawQuery(query_song_id,new String[]{String.valueOf(song_name)});
        int song_name_index=getSongId.getColumnIndex(SongContract.SongsTable.COLUMN_Song_ID);

        getSongId.moveToNext();

        String song_id=getSongId.getString(song_name_index);

        Cursor getPlaylistId=db.rawQuery(query_playlist_id,new String[]{String.valueOf(playlist_name)});
        int playlist_name_index=getPlaylistId.getColumnIndex(SongContract.PlaylistsTable.COLUMN_Playlist_ID);

        getPlaylistId.moveToNext();


        String playlist_id=getPlaylistId.getString(playlist_name_index);
    }*/
}
