package com.example.rabiaqayyum.fypinterface;

import java.io.Serializable;

/**
 * Created by RABIA QAYYUM on 4/26/2018.
 */


public class Song implements Serializable{

    private long id;
    private String title;
    private String artist;
    private String songURl;

    public Song(long songID, String songTitle, String songArtist, String url){
        id=songID;
        title=songTitle;
        artist=songArtist;
        this.songURl = url;
    }

    public long getID(){return id;}
    public String getTitle(){return title;}
    public String getArtist(){return artist;}
    public String getSongUrl(){return songURl;}

}