package com.example.rabiaqayyum.fypinterface;

import android.app.Activity;
import android.app.IntentService;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.MediaController;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import static android.content.ContentValues.TAG;

/**
 * Created by RABIA QAYYUM on 4/7/2018.
 */

public class songsList extends Activity {
    private ArrayList<Song> songList;
    ListView list;

    public static songPlaying sp = new songPlaying();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songs_listview);

        list = (ListView) findViewById(R.id.android_list);
        songList = new ArrayList<Song>();

        //get songs from device
        getSongList();

        //sort alphabetically by title
        Collections.sort(songList, new Comparator<Song>() {
            public int compare(Song a, Song b) {
                return a.getTitle().compareTo(b.getTitle());
            }
        });


        customListAdaptor adaptor = new customListAdaptor(this, songList);

        list.setAdapter(adaptor);

        //setup controller


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(songsList.this, songPlayer.class);

                String pos = String.valueOf(position);
                intent.putExtra("pos", pos);

                Bundle args = new Bundle();
                args.putSerializable("songarraylist", (Serializable) songList);
                intent.putExtra("bundle", args);

                if (sp.getSongID() != songList.get(position).getID()) {
                    sp.setSongID(position);
                    sp.setSongURL(songList.get(position).getSongUrl());
                    sp.startPlaying();
                }

                startActivity(intent);
            }
        });
    }


    //method to retrieve song info from device
    public void getSongList() {
        //query external audio
        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);
        //iterate over results if valid
        if (musicCursor != null && musicCursor.moveToFirst()) {
            //get columns
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);
            //add songs to list
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String songUrl = musicCursor.getString(musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                songList.add(new Song(thisId, thisTitle, thisArtist, songUrl));
            }
            while (musicCursor.moveToNext());
        }
    }
}
