package com.example.rabiaqayyum.fypinterface;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by RABIA QAYYUM on 4/10/2018.
 */

public class songPlayer extends Activity {

    //    public MediaPlayer mp;//assigning memory loc once or else multiple songs will play at once
    int position;

    ArrayList<Song> mySongs;
    Thread updateSeekBar;
    TextView songName;
    Thread playingSong;

    SeekBar sb;
    Button play, forward, reverse, next, previous;
    ImageView image;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songplayer);

        forward = (Button) findViewById(R.id.forward);
        previous = (Button) findViewById(R.id.previous);
        next = (Button) findViewById(R.id.next);
        reverse = (Button) findViewById(R.id.reverse);
        sb = (SeekBar) findViewById(R.id.seekbar);

        play = (Button) findViewById(R.id.play);
        image = (ImageView) findViewById(R.id.imageView);
        image.setImageResource(R.drawable.playingmusic);


        sb.setClickable(true);

        updateSeekBar = new Thread() {
            @Override
            public void run() {
                int totalDuration = songsList.sp.mp.getDuration();
                int currentPosition = 0;
                sb.setMax(totalDuration);
                while (currentPosition < totalDuration) {
                    try {
                        sleep(100);
                        currentPosition = songsList.sp.mp.getCurrentPosition();
                        sb.setProgress(currentPosition);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        };

        Bundle bundle = getIntent().getExtras();
        Intent intent = getIntent();

        Bundle args = intent.getBundleExtra("bundle");
        mySongs = (ArrayList<Song>) args.getSerializable("songarraylist");

        position = Integer.parseInt(bundle.getString("pos"));

        Song playSong = mySongs.get(position);
        final String currSong = playSong.getSongUrl();

        play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));

        sb.setMax(songsList.sp.mp.getDuration());
        updateSeekBar.start();

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                songsList.sp.mp.seekTo(seekBar.getProgress());
            }

        });


        play.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {
                                        // sb.setMax(mp.getDuration());

                                        if (songsList.sp.mp.isPlaying()) {
                                            play.setBackgroundDrawable(getResources().getDrawable(R.drawable.play));
                                            songsList.sp.mp.pause();
                                        } else {
                                            play.setBackgroundDrawable(getResources().getDrawable(R.drawable.pause));
                                            songsList.sp.mp.start();
                                        }

                                    }
                                }
        );
        forward.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // sb.setMax(mp.getDuration());
                songsList.sp.mp.seekTo(songsList.sp.mp.getCurrentPosition() + 5000);
            }
        });

        reverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // sb.setMax(mp.getDuration());
                songsList.sp.mp.seekTo(songsList.sp.mp.getCurrentPosition() - 5000);
            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (position == -1 || position == 0) {
                    position = mySongs.size();
                }

                position = position - 1;
                Log.i("infooo", "pos " + position);
                String song = mySongs.get(position).getSongUrl();

                songsList.sp.setSongID(position);
                songsList.sp.setSongURL(song);
                songsList.sp.startPlaying();

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (position == mySongs.size() || position == mySongs.size() - 1) {
                    position = -1;
                }

                position = position + 1;
                Log.i("infooo", "pos " + position + " my " + mySongs.size());
                String song = mySongs.get(position).getSongUrl();

                songsList.sp.setSongID(position);
                songsList.sp.setSongURL(song);
                songsList.sp.startPlaying();

            }
        });
    }
}
