package com.example.rabiaqayyum.fypinterface;

import android.media.MediaPlayer;
import android.util.Log;

/**
 * Created by Adeel on 5/10/2018.
 */

public class songPlaying {

    String songURL;
    int songID;
    int currentTime;
    MediaPlayer mp = new MediaPlayer();

    public songPlaying() {
    }

    public songPlaying(String url, int id) {
        this.songURL = url;
        this.songID = id;
    }

    public String getSongURL() {
        return songURL;
    }

    public void setSongURL(String songURL) {
        this.songURL = songURL;

        if(mp.isPlaying()) {
            mp.stop();
            mp.reset();
        }

    }

    public int getSongID() {
        return songID;
    }

    public void setSongID(int songID) {
        this.songID = songID;
    }

    public int getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(int currentTime) {
        this.currentTime = currentTime;
    }

    public void startPlaying() {

        try {

            mp.setDataSource(songURL);
            mp.prepareAsync();

            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                }
            });

        } catch (Exception e) {
            Log.e("MUSIC SERVICE", "Error setting data source", e);
        }
        currentTime = mp.getCurrentPosition();

    }

}
