package com.example.rabiaqayyum.fypinterface;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by RABIA QAYYUM on 4/7/2018.
 */

public class customListAdaptor extends BaseAdapter
{
    TextView txtTitle;
    Activity context;

    private ArrayList<Song> songs;
    public customListAdaptor( Activity c, ArrayList<Song> theSongs)
    {
        this.context=c;
        songs=theSongs;

    }


    @Override
    public int getCount() {
        return songs.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.songslist, null, true);

        txtTitle = (TextView) rowView.findViewById(R.id.Itemname);

        //get song using position
        Song currSong = songs.get(position);

        txtTitle.setText(currSong.getTitle());


        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);

        return rowView;
    }
}
