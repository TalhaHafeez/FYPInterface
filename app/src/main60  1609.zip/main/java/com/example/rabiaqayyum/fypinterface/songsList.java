package com.example.rabiaqayyum.fypinterface;

import android.app.ActionBar;
import android.app.Activity;
import android.app.IntentService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

import com.example.rabiaqayyum.fypinterface.Database.SongContract;
import com.example.rabiaqayyum.fypinterface.Database.SongDatabaseHelper;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static android.content.ContentValues.TAG;
import static java.security.AccessController.getContext;

/**
 * Created by RABIA QAYYUM on 4/7/2018.
 */

public class songsList extends ActionBarActivity implements  ClickListener {
    public static ArrayList<Song> songList;
   // private ArrayList<Images> imageList;
   public static final String Broadcast_PLAY_NEW_AUDIO = "com.example.rabiaqayyum.fypinterface.PlayNewAudio";
    RecyclerView list;
    TextView noSong;
    Button addSong;
    Button repeat;

    Toolbar toolbar;
    Button toolbarButton;


    static SongDatabaseHelper sdh;
    AddingRemovingSongs ars;
    Cursor res;
    boolean serviceBound = false;
    private MediaPlayerService player;
   // SharedPreference sharedPreference;




    ArrayList<String> songs;

    String playlistName;
    int songId;
    String songName,songPath;
    float songDuration;

    customListAdaptor adapter;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songs_listview);

        songs=new ArrayList<>();
        sdh=new SongDatabaseHelper(this);
        ars=new AddingRemovingSongs(this,new songsList());
     //   sharedPreference = new SharedPreference();


        list = (RecyclerView) findViewById(R.id.android_list);
        noSong=(TextView) findViewById(R.id.noSong);
        addSong=(Button)  findViewById(R.id.addSongs);

        repeat=(Button)findViewById(R.id.repeat);

        toolbar = (Toolbar) findViewById(R.id.toolbarlist);
        setSupportActionBar(toolbar);

        toolbarButton=(Button)findViewById(R.id.addSongsToolbar);




        LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
        list.setLayoutManager(llm);
        songList = new ArrayList<Song>();
      //  imageList=new ArrayList<Images>();

        Intent myIntent=getIntent();
        Bundle bundle=myIntent.getExtras();
        playlistName=bundle.getString("playlistName");


        Boolean isSongs=getSongList(playlistName);
        adapter = new customListAdaptor(this,songList,playlistName);
        adapter.setClickListener(this);
        list.setAdapter(adapter);

        toolbarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ars.addSongs(playlistName);
                adapter.notifyDataSetChanged();
                //adapter.notifyDataSetChanged();
            }
        });

//        adapter.notifyDataSetChanged();





        if(isSongs==false)
        {
            noSong.setVisibility(View.VISIBLE);
            addSong.setVisibility(View.VISIBLE);
            addSong.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ars.addSongs(playlistName);
                    adapter.notifyDataSetChanged();
                }
            });
           // adapter.notifyDataSetChanged();
        }
        else
        {
          //  adapter.notifyDataSetChanged();
            Collections.sort(songList, new Comparator<Song>() {
                public int compare(Song a, Song b) {
                    return a.getTitle().compareTo(b.getTitle());
                }
            });

            for(int i=0;i<songList.size();i++)
            {
                Log.e("song id",songList.get(i).getID()+"");
                Log.e("song name",songList.get(i).getTitle());

            }



        }


        //get songs from device
        //getSongList();

        //sort alphabetically by title


       /* Cursor res=sdh.getFavouriteSongs(playlistName);
        if(res!=null) {
            res.moveToFirst();
            do {

                int songNameIndex1 = res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_Name);
                String songName1 = res.getString(songNameIndex1);

                Log.e("song name", songName1);

            } while (res.moveToNext());
        }*/
        repeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent("repeatSong");
                intent.putExtra("repeat",true);
                sendBroadcast(intent);
            }
        });
    }


    //method to retrieve song info from device
   /* public void getSongList() {
        //query external audio
        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);

        //iterate over results if valid
        if (musicCursor != null && musicCursor.moveToFirst()) {
            //get columns
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);
            int data=musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            //add songs to list
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String songUrl = musicCursor.getString(musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA));




                int posColId = musicCursor.getColumnIndex(MediaStore.Audio.Media._ID);
                long songId = musicCursor.getLong(posColId);
                Uri songUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,songId);
                String[] dataColumn = {MediaStore.Audio.Media.DATA};


                Cursor coverCursor = getContentResolver().query(songUri, dataColumn, null, null, null);
                coverCursor.moveToFirst();
                int dataIndex = coverCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
                String filePath = coverCursor.getString(dataIndex);
                coverCursor.close();
                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                retriever.setDataSource(filePath);
                byte[] coverBytes = retriever.getEmbeddedPicture();

                songList.add(new Song(thisId, thisTitle, thisArtist, songUrl));
                if (coverBytes==null)
                {
                    Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.playingmusic);
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    coverBytes = stream.toByteArray();
                }
                imageList.add(new Images(thisId,coverBytes));

            }
            while (musicCursor.moveToNext());
        }
    }*/


    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MediaPlayerService.LocalBinder binder = (MediaPlayerService.LocalBinder) service;
            player = binder.getService();
            serviceBound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };


    public boolean getSongList(String playlistName)
    {
       Log.e("playlistname",playlistName.toString());
       //if(playlistName=="Happy")
       //{
            res = sdh.getAllSongs(playlistName);
       //}
        if(res.getCount()<=0&& res.moveToFirst()==false)
        {
            Log.e("cursor","null");
            return false;
        }
        else
        {
            res.moveToFirst();

            do {
                int songIdIndex=res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_ID);
                int songNameIndex=res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_Name);
                int songPathIndex=res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_Path);
                int songDurationIndex=res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_duration);

                songId=res.getInt(songIdIndex);
                songName=res.getString(songNameIndex);
                songPath=res.getString(songPathIndex);
                songDuration=res.getFloat(songDurationIndex);

                // String[] projection = { MediaStore.Audio.Media.DATA };
                //CursorLoader loader = new CursorLoader(getApplicationContext(), songPath, projection, null, null, null);

                songList.add(new Song(songId,songName,songPath,songDuration));

            }while(res.moveToNext());
            return true;
        }




   }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putBoolean("serviceStatus", serviceBound);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        serviceBound = savedInstanceState.getBoolean("serviceStatus");
    }


    @Override
    protected void onDestroy()
    {
        super.onDestroy();

    }
    @Override
    public void itemClicked(View view, int position,String playlistName) {

       int songPosition=position;
       Log.e("playlistname1",playlistName);
       String previousPlaylist=new StorageUtility(getApplicationContext()).loadPlaylist();
/*
       String songPath=songList.get(position).getSongUrl();

       String songName=songList.get(position).getTitle();

       float songDuration=songList.get(position).getSongDuration();*/


        boolean isServiceRunning = Utilities.isServiceRunning(MediaPlayerService.class.getName(), getApplicationContext());
       if(!isServiceRunning ) {
           StorageUtility storage = new StorageUtility(getApplicationContext());
           Log.e("pl",playlistName);
           storage.storePlaylist(playlistName);
           storage.storeAudio(songList);
           storage.storeAudioIndex(songPosition);


           Intent playerIntent = new Intent(this, MediaPlayerService.class);
           playerIntent.putExtra("currentSongPosition","0");
           startService(playerIntent);
           //bindService(playerIntent, serviceConnection, Context.BIND_AUTO_CREATE);
           Intent playing=new Intent(this,songPlayer.class);

           startActivity(playing);
          // finish();



       }
       /* else if(isServiceRunning==true && !playlistName.equalsIgnoreCase(previousPlaylist))
        {
            Intent newIntent=new Intent(this,MediaPlayerService.class);
            stopService(newIntent);
            Log.e("play",previousPlaylist);
            StorageUtility storage = new StorageUtility(getApplicationContext());
            Log.e("pl2",playlistName);
            storage.storePlaylist(playlistName);
            storage.storeAudio(songList);
            storage.storeAudioIndex(songPosition);


            Intent playerIntent = new Intent(this, MediaPlayerService.class);
            playerIntent.putExtra("currentSongPosition","0");
            startService(playerIntent);
            //bindService(playerIntent, serviceConnection, Context.BIND_AUTO_CREATE);
            Intent playing=new Intent(this,songPlayer.class);

            startActivity(playing);
        }*/
       else
       {
           StorageUtility storage = new StorageUtility(getApplicationContext());
           Log.e("pl",playlistName);
           storage.storePlaylist(playlistName);
           storage.storeAudio(songList);
           storage.storeAudioIndex(songPosition);

           //Service is active
           //Send a broadcast to the service -> PLAY_NEW_AUDIO
           Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
           sendBroadcast(broadcastIntent);
           Intent playing=new Intent(this,songPlayer.class);
           startActivity(playing);
          // finish();
       }



       /* MusicFragement fragment = new MusicFragement();

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.your_placeholder, fragment);
        transaction.commit();*/


      /* Intent newIntent=new Intent(songsList.this,songPlayer.class);
       newIntent.putExtra("position",position);
       Bundle args = new Bundle();
       args.putSerializable("songarraylist", (Serializable) songList);
       newIntent.putExtra("bundle",args);
       startActivity(newIntent);*/


      /*  Intent intent = new Intent(songsList.this, songPlayer.class);

        String pos = String.valueOf(position);
        intent.putExtra("pos", pos);

        Bundle args = new Bundle();
        args.putSerializable("songarraylist", (Serializable) songList);
        intent.putExtra("bundle", args);




        if (sp.getSongID() != songList.get(position).getID()) {
            sp.setSongID(position);
            sp.setSongURL(songList.get(position).getSongUrl());
            sp.setSongPosition(position);
            sp.startPlaying();
        }

        startActivity(intent);*/
    }

    @Override
    public void popUpClicked(View view,final int listPosition) {
      /*  String name=songList.get(listPosition).getTitle();
        String path=songList.get(listPosition).getSongUrl();
        Cursor res=sdh.getSingleSong(path);
        int songId;
        res.moveToFirst();
        do
        {
            int songIdIndex=res.getColumnIndex(SongContract.SongsTable.COLUMN_Song_ID);
            songId=res.getInt(songIdIndex);
        }while(res.moveToNext());
        */
        PopupMenu popup = new PopupMenu(this, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.songs_options_menu, popup.getMenu());

        Log.e("pop clicked","for removing");

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                             @Override
                                             public boolean onMenuItemClick(MenuItem item) {
                                                 //do your things in each of the following cases
                                                 switch (item.getItemId()) {

                                                     case R.id.deletesongs:

                                                         int songId;
                                                         songId=songList.get(listPosition).getID();
                                                         int rowsDeleted=sdh.delete(songId);

                                                         if(rowsDeleted>0)
                                                         {
                                                             songList.remove(listPosition);
                                                             adapter.notifyItemRemoved(listPosition);
                                                            // songsList.this.notifyAll();
                                                            // getSongList(playlistName);

                                                         }

                                                         return true;
                                                     default:
                                                         return false;
                                                 }
                                             }
                                         });
        popup.show();

       /* int songId;
        songId=songList.get(listPosition).getID();
        int rowsDeleted=sdh.delete(songId);

        if(rowsDeleted>0)
        {
            songList.remove(listPosition);
        }*/

    }

    @Override
    public void favouriteButton(View view, int listPosition, String playlistName, boolean fav) {
        if(fav==false)
        {
            view.setSelected(true);
           // sharedPreference.addFavorite(this, songList.get(listPosition));
            sdh.updateSongs(songList.get(listPosition).getID(),1);
        }
        else
        {
            view.setSelected(false);
           // sharedPreference.removeFavorite(this, songList.get(listPosition));
            sdh.updateSongs(songList.get(listPosition).getID(),0);
        }
    }



/*
    @Override
    public void favouriteButton(View view, int listPosition, String playlistName) {
        if(view.isSelected()==false)
        {
            view.setSelected(true);
            sdh.updateSongs(songList.get(listPosition).getID(),1);

            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("tgpref", true); // value to store
            editor.commit();
        }
        else
        {
            view.setSelected(false);
            sdh.updateSongs(songList.get(listPosition).getID(),0);
        }
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7 && resultCode == RESULT_OK) {
            String song[];
            Uri uri = data.getData();

            //if(uri.getScheme().equals("content"))
            //  {
            // Log.e("content","the path has content");
            //}
            if (uri != null) {
                song = getRealPathFromURI(getApplicationContext(), uri);
                for (int i = 0; i < song.length; i++) {
                    Log.e("path", song[i]);
                }
            } else {
                song = null;
            }


            ars.addToDatabaseAndListView(song[1], song[0], Float.parseFloat(song[2]));


        }
    }
    private String[] getRealPathFromURI(Context context, Uri contentUri) {
        // String[] projection = { MediaStore.Audio.Media.DATA };
        String[] song=new String[4];
        CursorLoader loader = new CursorLoader(context, contentUri, null, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int path_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
        int name_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
        int duration_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
        int artist_index=cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
        cursor.moveToFirst();
        //do {
        String songPath=cursor.getString(path_index);
        String songName=cursor.getString(name_index);
        String songDuration=cursor.getString(duration_index);
        String songArtist=cursor.getString(artist_index);

        song[0]=songPath;
        song[1]=songName;
        song[2]=songDuration;
        song[3]=songArtist;
        // }while (cursor.moveToNext());
        return song;

    }
}
