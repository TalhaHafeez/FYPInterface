package com.example.rabiaqayyum.fypinterface;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webview extends AppCompatActivity {
private WebView webView;
    @Override
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);

        webView =(WebView) findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        Intent myIntent = getIntent();
        String playlistName = myIntent.getExtras().getString("playlistName");
        Log.e("playlistName",playlistName);

        if (playlistName.equalsIgnoreCase("Angry")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=angry%20songs");
        }

        else if (playlistName.equalsIgnoreCase("fear")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=horror%20songs");
        }

        else if (playlistName.equalsIgnoreCase("neutral")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=new%20songs");
        }

        else if (playlistName.equalsIgnoreCase("Surprise")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=party%20songs");
        }

        else if (playlistName.equalsIgnoreCase("Happy")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=happy%20songs");
        }

        else if (playlistName.equalsIgnoreCase("sad")){
            webView.loadUrl("https://soundcloud.com/search/sounds?q=sad%20songs");
        }



    }
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }

    }
}

