package com.example.rabiaqayyum.fypinterface;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.widget.PopupMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.rabiaqayyum.fypinterface.emotionDetection.emotionDetectionClass;

import java.io.ByteArrayOutputStream;

import static android.app.Activity.RESULT_OK;


public class FragmentTwo extends Fragment implements View.OnClickListener {

    emotionDetectionClass edc;
    Button b2,b3,b4,b5,b6,b7;
    final int request_code=100;
    Button play;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fragment_two, container, false);
        play=(Button)view.findViewById(R.id.play);




        b2=(Button) view.findViewById(R.id.button2);
        b3=(Button) view.findViewById(R.id.button3);
        b4=(Button) view.findViewById(R.id.button4);
        b5=(Button) view.findViewById(R.id.button5);
        b6=(Button) view.findViewById(R.id.button6);
        b7=(Button) view.findViewById(R.id.button7);

        //*********************************ON CLICK LISTENER***************************
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent myIntent = new Intent(getActivity(), webView.class);
                myIntent.putExtra("playlistName",b2.getText().toString());
                startActivity(myIntent);*/

               /*Intent myIntent=getIntent();
               String playlistName=myIntent.getExtras().getString("playlistName");
               if(playlistName.equalsIgnoreCase("Happy"))
               {
                   //send url to webview with happy
               }*/
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b2.getText().toString());
                startActivity(myIntent);

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b3.getText().toString());
                startActivity(myIntent);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b4.getText().toString());
                startActivity(myIntent);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b5.getText().toString());
                startActivity(myIntent);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b6.getText().toString());
                startActivity(myIntent);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity(), webview.class);
                myIntent.putExtra("playlistName",b7.getText().toString());
                startActivity(myIntent);
            }
        });

        //**********************************ON LONG CLICK LISTENER******************************
//        b2.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b2, Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });
//
//        b3.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b3,Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });
//
//        b4.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b4,Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });
//
//        b5.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b5,Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });
//
//        b6.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b6,Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });
//
//        b7.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                final PopupMenu popupMenu = new PopupMenu(getContext(), b7,Gravity.CENTER);
//                popupMenu.getMenuInflater().inflate(R.menu.playlist2popup, popupMenu.getMenu());
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                                                         @Override
//                                                         public boolean onMenuItemClick(MenuItem item) {
//                                                             return false;
//                                                         }
//                                                     }
//                );
//                popupMenu.show();
//                return true;
//            }
//
//
//        });

        play.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        /*if(v.getId()==play.getId())
        {
            cameraClass cc=new cameraClass(v);
        }*/
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        /*fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);*/
        startActivityForResult(intent,request_code);



    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100&&resultCode==RESULT_OK)
        {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, bStream);
            byte[] byteArray = bStream.toByteArray();

            edc=new emotionDetectionClass(getContext(),byteArray);
//            edc.callDetection();


            // Intent myIntent = new Intent(getActivity(), songsList.class);
            //startActivity(myIntent);
        }
    }
}

